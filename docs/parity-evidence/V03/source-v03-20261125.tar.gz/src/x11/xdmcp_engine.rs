//! Owned Linux nested XDMCP engine. Never starts or stops a display manager.
use super::{
    XServerManager,
    engine::OwnedProcess,
    xdmcp::{XdmcpConfig, check_cancelled, engine_arguments},
};
use std::{
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver},
    },
    time::{Duration, Instant},
};

pub const LINUX_XEPHYR_ARTIFACT: &str = "xephyr-21.1.26-arch-x86_64";
/// Per-session ownership. The child stops before its private credentials are removed.
pub struct XdmcpSession {
    process: OwnedProcess,
    display: String,
    authority: PathBuf,
    log: std::process::ChildStderr,
    diagnostics: Vec<u8>,
    _runtime: tempfile::TempDir,
}
impl XdmcpSession {
    pub fn display(&self) -> &str {
        &self.display
    }
    pub fn authority_path(&self) -> &Path {
        &self.authority
    }
    pub fn process_id(&self) -> Option<u32> {
        self.process.id()
    }
    pub fn is_running(&mut self) -> Result<bool, String> {
        use std::io::Read;
        let mut buffer = [0; 4096];
        for _ in 0..4 {
            match self.log.read(&mut buffer) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if self.diagnostics.len() < 4096 {
                        self.diagnostics
                            .extend_from_slice(&buffer[..n.min(4096 - self.diagnostics.len())]);
                    }
                }
            }
        }
        self.process.is_running().map_err(|e| e.to_string())
    }
    pub fn stop_owned(mut self) -> Result<(), String> {
        self.process.stop().map_err(|e| e.to_string())
    }
}
impl XServerManager {
    /// Dedicated XDMCP-capable engine; never passes XDMCP arguments to Xwayland.
    pub fn start_xdmcp_cancellable(
        &self,
        config: XdmcpConfig,
        width: u32,
        height: u32,
        cancelled: &AtomicBool,
    ) -> Result<XdmcpSession, String> {
        let root = match &self.installation {
            Some(path) => path.clone(),
            None => std::env::current_exe()
                .map_err(|e| e.to_string())?
                .parent()
                .ok_or("Cannot locate the TermCraft installation")?
                .to_path_buf(),
        };
        start(&root, config, width, height, cancelled)
    }
}
/// Holds the session on its worker, so drop/cancellation never waits on the render thread.
pub struct ManagedXdmcp {
    cancelled: Arc<AtomicBool>,
    status: Receiver<Result<String, String>>,
    finished: Arc<AtomicBool>,
}
impl ManagedXdmcp {
    pub fn start(
        manager: XServerManager,
        config: XdmcpConfig,
        width: u32,
        height: u32,
    ) -> Result<Self, String> {
        // Validate before allocating a worker. Engine chooses and verifies a free display.
        engine_arguments(&config, config.display.unwrap_or(100), width, height)?;
        let cancelled = Arc::new(AtomicBool::new(false));
        let stop = cancelled.clone();
        let finished = Arc::new(AtomicBool::new(false));
        let done = finished.clone();
        let (sender, status) = mpsc::sync_channel(2);
        std::thread::Builder::new()
            .name("termcraft-xdmcp-session".into())
            .spawn(move || {
                let result = manager
                    .start_xdmcp_cancellable(config, width, height, &stop)
                    .and_then(|mut session| {
                        if stop.load(Ordering::Relaxed) {
                            return session.stop_owned();
                        }
                        if sender
                            .send(Ok(format!(
                                "Owned X server/listener {} ready; waiting for the remote display manager",
                                session.display()
                            )))
                            .is_err()
                        {
                            return session.stop_owned();
                        }
                        while !stop.load(Ordering::Relaxed) {
                            if !session.is_running()? {
                                return Ok(());
                            }
                            std::thread::sleep(Duration::from_millis(30));
                        }
                        session.stop_owned()
                    });
                done.store(true, Ordering::Relaxed);
                let _ = sender.try_send(result.map(|()| "XDMCP session ended".into()));
            })
            .map_err(|e| e.to_string())?;
        Ok(Self {
            cancelled,
            status,
            finished,
        })
    }
    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::Relaxed)
    }
    pub fn is_finished(&self) -> bool {
        self.finished.load(Ordering::Relaxed)
    }
    pub fn poll(&self) -> Option<Result<String, String>> {
        self.status.try_recv().ok()
    }
}
impl Drop for ManagedXdmcp {
    fn drop(&mut self) {
        self.cancel()
    }
}

#[cfg(all(target_os = "linux", target_arch = "x86_64", target_env = "gnu"))]
fn start(
    root: &Path,
    config: XdmcpConfig,
    width: u32,
    height: u32,
    cancelled: &AtomicBool,
) -> Result<XdmcpSession, String> {
    use std::{
        io::{Read, Write},
        os::{
            fd::AsRawFd,
            unix::{
                fs::{OpenOptionsExt, PermissionsExt},
                process::CommandExt,
            },
        },
        process::{Command, Stdio},
    };
    let deadline = Instant::now() + Duration::from_secs(8);
    super::xdmcp_payload::check_budget(cancelled, deadline)?;
    let mut random = [0; 2];
    getrandom::fill(&mut random).map_err(|e| e.to_string())?;
    let display = config
        .display
        .unwrap_or(100 + u16::from_ne_bytes(random) % 900);
    let args = engine_arguments(&config, display, width, height)?;
    // Refuse occupied displays before launching; the engine's exclusive lock and
    // -nopn also reject races and partial binds. Never remove an existing socket/lock.
    let socket = PathBuf::from(format!("/tmp/.X11-unix/X{display}"));
    if socket.symlink_metadata().is_ok()
        || Path::new(&format!("/tmp/.X{display}-lock"))
            .symlink_metadata()
            .is_ok()
    {
        return Err(format!(
            "Display :{display} is already occupied; choose another display"
        ));
    }
    if std::env::var_os("DISPLAY").is_none_or(|v| v.is_empty()) {
        return Err(
            "The owned Xephyr XDMCP candidate requires a host X11 display for its nested window"
                .into(),
        );
    }
    let binary = root.join("x11/linux-x86_64/Xephyr");
    let executable =
        super::xdmcp_payload::load_pinned(&binary, cancelled, deadline).map_err(|error| {
            format!(
                "Install/verify the owned {LINUX_XEPHYR_ARTIFACT} engine ({}): {error}",
                binary.display()
            )
        })?;
    let runtime = tempfile::Builder::new()
        .prefix("termcraft-xdmcp-")
        .permissions(std::fs::Permissions::from_mode(0o700))
        .tempdir()
        .map_err(|e| e.to_string())?;
    let authority = runtime.path().join("authority");
    let mut cookie = zeroize::Zeroizing::new([0; 16]);
    getrandom::fill(cookie.as_mut()).map_err(|e| e.to_string())?;
    let mut auth = std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .mode(0o600)
        .open(&authority)
        .map_err(|e| e.to_string())?;
    auth.write_all(&65535u16.to_be_bytes())
        .map_err(|e| e.to_string())?;
    for field in [
        b"".as_slice(),
        display.to_string().as_bytes(),
        b"MIT-MAGIC-COOKIE-1",
        cookie.as_slice(),
    ] {
        auth.write_all(&(field.len() as u16).to_be_bytes())
            .and_then(|()| auth.write_all(field))
            .map_err(|e| e.to_string())?;
    }
    drop(auth);
    let mut command = Command::new(format!("/proc/self/fd/{}", executable.as_raw_fd()));
    command
        .arg0(&binary)
        .args(args)
        .arg("-auth")
        .arg(&authority)
        .arg("-displayfd")
        .arg("1")
        .env_remove("WAYLAND_SOCKET")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    super::xdmcp_payload::check_budget(cancelled, deadline)?;
    let mut child = command
        .spawn()
        .map_err(|e| format!("Could not start owned Xephyr: {e}"))?;
    let mut ready = child.stdout.take().unwrap();
    let mut log = child.stderr.take().unwrap();
    for fd in [ready.as_raw_fd(), log.as_raw_fd()] {
        let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
        if flags < 0 || unsafe { libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK) } < 0 {
            let _ = child.kill();
            let _ = child.wait();
            return Err("Could not monitor the owned XDMCP engine".into());
        }
    }
    let mut process = OwnedProcess::new(child);
    let mut output = Vec::new();
    let mut diagnostics = Vec::new();
    while Instant::now() < deadline {
        super::xdmcp_payload::check_budget(cancelled, deadline)?;
        let mut buffer = [0; 256];
        if let Ok(n) = log.read(&mut buffer) {
            if diagnostics.len() < 4096 {
                diagnostics.extend_from_slice(&buffer[..n.min(4096 - diagnostics.len())]);
            }
        }
        if !process.is_running().map_err(|e| e.to_string())? {
            return Err(format!(
                "Owned Xephyr exited during XDMCP startup: {}",
                String::from_utf8_lossy(&diagnostics)
            ));
        }
        if let Ok(n) = ready.read(&mut buffer) {
            output.extend_from_slice(&buffer[..n]);
            if output.len() > 16 {
                return Err("Invalid XDMCP engine readiness response".into());
            }
        }
        if output.ends_with(b"\n") {
            if std::str::from_utf8(&output)
                .ok()
                .and_then(|s| s.trim().parse::<u16>().ok())
                != Some(display)
            {
                return Err("XDMCP engine selected an unexpected display".into());
            }
            // Peer credentials correlate the socket with the child, never another display owner.
            let stream = connect_ready_socket(&socket, deadline, cancelled)?;
            let mut peer = std::mem::MaybeUninit::<libc::ucred>::uninit();
            let mut size = std::mem::size_of::<libc::ucred>() as libc::socklen_t;
            if unsafe {
                libc::getsockopt(
                    stream.as_raw_fd(),
                    libc::SOL_SOCKET,
                    libc::SO_PEERCRED,
                    peer.as_mut_ptr().cast(),
                    &mut size,
                )
            } < 0
                || size as usize != std::mem::size_of::<libc::ucred>()
                || unsafe { peer.assume_init() }.pid != process.id().unwrap() as libc::pid_t
            {
                return Err("XDMCP display socket belongs to an unexpected process".into());
            }
            super::xdmcp_listener::verify_tcp_listener(
                6000 + display,
                process
                    .id()
                    .ok_or("Owned XDMCP process exited during listener verification")?,
            )?;
            super::xdmcp_payload::check_budget(cancelled, deadline)?;
            return Ok(XdmcpSession {
                process,
                display: format!(":{display}"),
                authority,
                log,
                diagnostics,
                _runtime: runtime,
            });
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    Err("Timed out waiting for the owned Xephyr XDMCP display".into())
}
#[cfg(all(target_os = "linux", target_arch = "x86_64", target_env = "gnu"))]
fn connect_ready_socket(
    path: &Path,
    deadline: Instant,
    cancelled: &AtomicBool,
) -> Result<std::os::unix::net::UnixStream, String> {
    use std::os::{
        fd::{AsRawFd, FromRawFd},
        unix::net::UnixStream,
    };
    let path = path.as_os_str().as_encoded_bytes();
    let mut address: libc::sockaddr_un = unsafe { std::mem::zeroed() };
    if path.len() >= address.sun_path.len() || path.contains(&0) {
        return Err("Invalid owned X display socket path".into());
    }
    address.sun_family = libc::AF_UNIX as libc::sa_family_t;
    for (dst, src) in address.sun_path.iter_mut().zip(path) {
        *dst = *src as libc::c_char;
    }
    loop {
        check_cancelled(cancelled)?;
        if Instant::now() >= deadline {
            return Err("Timed out connecting to owned XDMCP display".into());
        }
        let fd = unsafe {
            libc::socket(
                libc::AF_UNIX,
                libc::SOCK_STREAM | libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC,
                0,
            )
        };
        if fd < 0 {
            return Err(std::io::Error::last_os_error().to_string());
        }
        let stream = unsafe { UnixStream::from_raw_fd(fd) };
        if unsafe {
            libc::connect(
                stream.as_raw_fd(),
                (&address as *const libc::sockaddr_un).cast(),
                std::mem::size_of::<libc::sockaddr_un>() as libc::socklen_t,
            )
        } == 0
        {
            return Ok(stream);
        }
        let error = std::io::Error::last_os_error();
        if !matches!(
            error.raw_os_error(),
            Some(libc::EAGAIN | libc::EINPROGRESS | libc::EINTR)
        ) {
            return Err(error.to_string());
        }
        std::thread::sleep(
            Duration::from_millis(10).min(deadline.saturating_duration_since(Instant::now())),
        );
    }
}

#[cfg(not(all(target_os = "linux", target_arch = "x86_64", target_env = "gnu")))]
fn start(_: &Path, _: XdmcpConfig, _: u32, _: u32, _: &AtomicBool) -> Result<XdmcpSession, String> {
    Err("The owned native XDMCP engine has not passed its platform qualification. Installed-client fallback is not automatic".into())
}

#[cfg(all(test, target_os = "linux", target_arch = "x86_64", target_env = "gnu"))]
mod tests {
    use super::*;
    use std::{
        io::Write,
        os::unix::{fs::PermissionsExt, process::CommandExt},
        process::{Child, Command, Stdio},
    };
    struct DisplayManager(Child);
    impl Drop for DisplayManager {
        fn drop(&mut self) {
            unsafe {
                libc::kill(-(self.0.id() as libc::pid_t), libc::SIGTERM);
            }
            let _ = self.0.wait();
        }
    }
    #[test]
    fn saturated_socket_readiness_stays_bounded_and_cancellable() {
        use std::os::{fd::AsRawFd, unix::net::UnixListener};
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("ready");
        let listener = UnixListener::bind(&path).unwrap();
        assert_eq!(unsafe { libc::listen(listener.as_raw_fd(), 1) }, 0);
        let mut clients = Vec::new();
        for _ in 0..256 {
            match connect_ready_socket(
                &path,
                Instant::now() + Duration::from_millis(2),
                &AtomicBool::new(false),
            ) {
                Ok(client) => clients.push(client),
                Err(_) => break,
            }
        }
        assert!(!clients.is_empty());
        let start = Instant::now();
        assert!(
            connect_ready_socket(
                &path,
                start + Duration::from_millis(20),
                &AtomicBool::new(false)
            )
            .unwrap_err()
            .contains("Timed out")
        );
        assert!(start.elapsed() < Duration::from_millis(500));
        assert!(
            connect_ready_socket(
                &path,
                Instant::now() + Duration::from_secs(1),
                &AtomicBool::new(true)
            )
            .unwrap_err()
            .contains("cancel")
        );
    }
    #[test]
    fn legacy_session_json_preserves_disabled_xdmcp_defaults() {
        let session: crate::model::Session =
            serde_json::from_str(r#"{"protocol":"XDMCP","host":"legacy.example","port":1177}"#)
                .unwrap();
        assert!(session.xdmcp_options.is_default());
        assert!(
            serde_json::to_value(session)
                .unwrap()
                .get("xdmcp_options")
                .is_none()
        );
    }
    #[test]
    fn cancellation_before_start_never_spawns_engine() {
        let result = XServerManager::for_installation(PathBuf::from("/nonexistent"))
            .start_xdmcp_cancellable(XdmcpConfig::default(), 800, 600, &AtomicBool::new(true));
        assert!(result.err().unwrap().contains("cancel"));
    }
    #[test]
    #[ignore = "must run inside tests/support/run_xserver_isolated.sh with the private xdm package"]
    fn actual_xdm_nondefault_port_opens_selected_display_and_cleanup_preserves_host() {
        assert_eq!(
            std::env::var("TERMCRAFT_TEST_XSERVER_ISOLATED").as_deref(),
            Ok("1")
        );
        let host = std::env::var("TERMCRAFT_TEST_XSERVER_FIXTURE_PID").unwrap();
        let package = PathBuf::from(std::env::var("TERMCRAFT_TEST_XDMCP_PACKAGE").unwrap());
        let fixture = PathBuf::from(std::env::var("TERMCRAFT_TEST_XDMCP_FIXTURE").unwrap());
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir(dir.path().join("auth")).unwrap();
        std::fs::write(dir.path().join("servers"), b"").unwrap();
        std::fs::write(dir.path().join("access"), b"127.0.0.1\n192.0.2.1\n").unwrap();
        let marker = dir.path().join("managed");
        let setup = dir.path().join("setup");
        std::fs::write(
            &setup,
            format!(
                "#!/bin/sh\nexec /usr/bin/python '{}' '{}'\n",
                fixture.join("xdmcp_window.py").display(),
                marker.display()
            ),
        )
        .unwrap();
        std::fs::set_permissions(&setup, std::fs::Permissions::from_mode(0o700)).unwrap();
        let config = dir.path().join("config");
        let mut file = std::fs::File::create(&config).unwrap();
        for (key, value) in [
            (
                "DisplayManager.servers",
                dir.path().join("servers").display().to_string(),
            ),
            (
                "DisplayManager.accessFile",
                dir.path().join("access").display().to_string(),
            ),
            (
                "DisplayManager.authDir",
                dir.path().join("auth").display().to_string(),
            ),
            (
                "DisplayManager.pidFile",
                dir.path().join("xdm.pid").display().to_string(),
            ),
            (
                "DisplayManager.errorLogFile",
                dir.path().join("xdm.log").display().to_string(),
            ),
            ("DisplayManager.requestPort", "1177".into()),
            ("DisplayManager.daemonMode", "false".into()),
            ("DisplayManager*authorize", "true".into()),
            ("DisplayManager*authName", "MIT-MAGIC-COOKIE-1".into()),
            ("DisplayManager*setup", setup.display().to_string()),
            ("DisplayManager*openDelay", "1".into()),
            ("DisplayManager*openRepeat", "3".into()),
            (
                "DisplayManager*greeterLib",
                fixture.join("libXdmGreet.so").display().to_string(),
            ),
        ] {
            writeln!(file, "{key}: {value}").unwrap();
        }
        drop(file);
        let manager_log = std::fs::File::create(dir.path().join("manager.log")).unwrap();
        let mut command = Command::new(fixture.join("xdm"));
        command
            .env("LD_LIBRARY_PATH", fixture.join("lib"))
            .args(["-nodaemon", "-debug", "0", "-config"])
            .arg(&config)
            .stdout(Stdio::from(manager_log.try_clone().unwrap()))
            .stderr(Stdio::from(manager_log));
        unsafe {
            command.pre_exec(|| {
                if libc::setpgid(0, 0) < 0 {
                    return Err(std::io::Error::last_os_error());
                }
                Ok(())
            });
        }
        let mut dm = DisplayManager(command.spawn().unwrap());
        let endpoint = "127.0.0.1:1177".parse().unwrap();
        let start = Instant::now();
        loop {
            let replies = super::super::xdmcp::discover(
                &super::super::xdmcp::DiscoveryRequest::direct(endpoint),
                &AtomicBool::new(false),
            )
            .unwrap();
            if !replies.is_empty() {
                break;
            }
            assert!(
                start.elapsed() < Duration::from_secs(5),
                "xdm did not answer: {}",
                format!(
                    "{} {}",
                    std::fs::read_to_string(dir.path().join("manager.log")).unwrap(),
                    std::fs::read_to_string(dir.path().join("xdm.log")).unwrap_or_default()
                )
            );
        }
        let options = XdmcpConfig {
            selected_endpoint: Some(endpoint),
            display: Some(177),
            advertise_address: Some("192.0.2.1".parse().unwrap()),
            allow_network_listener: true,
            ..Default::default()
        };
        let manager = XServerManager::for_installation(package);
        let mut session = manager
            .start_xdmcp_cancellable(options, 800, 600, &AtomicBool::new(false))
            .unwrap_or_else(|e| {
                panic!(
                    "{e}; xdm: {}",
                    format!(
                        "{} {}",
                        std::fs::read_to_string(dir.path().join("manager.log")).unwrap(),
                        std::fs::read_to_string(dir.path().join("xdm.log")).unwrap_or_default()
                    )
                )
            });
        assert_eq!(session.display(), ":177");
        let pid = session.process_id().unwrap();
        let auth = session.authority_path().to_path_buf();
        let start = Instant::now();
        while !marker.exists() {
            assert!(
                session.is_running().unwrap(),
                "engine: {}; xdm: {}",
                String::from_utf8_lossy(&session.diagnostics),
                format!(
                    "{} {}",
                    std::fs::read_to_string(dir.path().join("manager.log")).unwrap(),
                    std::fs::read_to_string(dir.path().join("xdm.log")).unwrap_or_default()
                )
            );
            assert!(dm.0.try_wait().unwrap().is_none());
            assert!(
                start.elapsed() < Duration::from_secs(8),
                "xdm did not manage the display: {}",
                format!(
                    "{} {}",
                    std::fs::read_to_string(dir.path().join("manager.log")).unwrap(),
                    std::fs::read_to_string(dir.path().join("xdm.log")).unwrap_or_default()
                )
            );
            std::thread::sleep(Duration::from_millis(40));
        }
        let observed = std::fs::read_to_string(&marker).unwrap();
        assert!(observed.contains(":177"), "{observed}");
        assert!(
            observed.contains("800x600") && observed.contains("green pixel verified"),
            "{observed}"
        );
        // The manager's authenticated client is still live. A wrong cookie must fail.
        {
            use std::{
                io::{Read, Write},
                os::unix::net::UnixStream,
            };
            let mut client = UnixStream::connect("/tmp/.X11-unix/X177").unwrap();
            client
                .set_read_timeout(Some(Duration::from_secs(1)))
                .unwrap();
            let mut setup = [0u8; 48];
            setup[0] = b'l';
            setup[2] = 11;
            setup[6] = 18;
            setup[8] = 16;
            setup[12..30].copy_from_slice(b"MIT-MAGIC-COOKIE-1");
            setup[32..].fill(0x5a);
            client.write_all(&setup).unwrap();
            let mut reply = [0];
            client.read_exact(&mut reply).unwrap();
            assert_eq!(reply[0], 0, "wrong cookie was admitted");
        }
        std::fs::remove_file(&marker).unwrap();
        let output = Command::new("/usr/bin/python")
            .arg(fixture.join("xdmcp_output.py"))
            .env("DISPLAY", ":0")
            .env_remove("XAUTHORITY")
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let output = String::from_utf8(output.stdout).unwrap();
        let parts = output.split_whitespace().collect::<Vec<_>>();
        assert_eq!(parts.len(), 3);
        let monitor = parts[0].to_string();
        let host_dimensions = format!("{}x{}", parts[1], parts[2]);
        let mut second = manager
            .start_xdmcp_cancellable(
                XdmcpConfig {
                    selected_endpoint: Some(endpoint),
                    display: Some(178),
                    fullscreen: true,
                    monitor: Some(monitor),
                    advertise_address: Some("192.0.2.1".parse().unwrap()),
                    allow_network_listener: true,
                    ..Default::default()
                },
                640,
                480,
                &AtomicBool::new(false),
            )
            .unwrap();
        let second_pid = second.process_id().unwrap();
        let second_auth = second.authority_path().to_path_buf();
        let start = Instant::now();
        while !marker.exists() {
            assert!(second.is_running().unwrap());
            assert!(start.elapsed() < Duration::from_secs(5));
            std::thread::sleep(Duration::from_millis(20));
        }
        let observed_second = std::fs::read_to_string(&marker).unwrap();
        assert!(
            observed_second.contains(":178") && observed_second.contains(&host_dimensions),
            "selected monitor geometry was not applied: {observed_second}; expected {host_dimensions}"
        );
        assert!(Path::new(&format!("/proc/{host}")).exists());
        session.stop_owned().unwrap();
        assert!(
            second.is_running().unwrap(),
            "closing the first session stopped the second"
        );
        second.stop_owned().unwrap();
        assert!(!Path::new(&format!("/proc/{second_pid}")).exists());
        assert!(!second_auth.exists());
        assert!(!Path::new(&format!("/proc/{pid}")).exists());
        assert!(!auth.exists());
        assert!(Path::new(&format!("/proc/{host}")).exists());
        println!(
            "Real xdm discovery on UDP 1177, MANAGE and authenticated mapped window on :177; wrong cookie rejected; second session survived first close; both owned PID/auth cleaned; isolated Cage display survived. Clipboard Disabled: no host bridge created."
        );
    }
}
