//! Bounded XDMCP discovery. Replies are unauthenticated advertisements, never credentials.

use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    net::{IpAddr, Ipv4Addr, SocketAddr, UdpSocket},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver},
    },
    time::{Duration, Instant},
};

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum QueryMode {
    #[default]
    Direct,
    Indirect,
    Broadcast,
}
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ClipboardPolicy {
    #[default]
    Disabled,
    Bidirectional,
}
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct XdmcpConfig {
    pub mode: QueryMode,
    pub selected_endpoint: Option<SocketAddr>,
    pub display: Option<u16>,
    pub monitor: Option<String>,
    pub fullscreen: bool,
    pub keyboard: String,
    pub clipboard: ClipboardPolicy,
    /// Address advertised to the manager, NOT a restriction on the X11 listener.
    pub advertise_address: Option<Ipv4Addr>,
    /// Explicit permission for the upstream engine to listen on all X11 TCP interfaces.
    pub allow_network_listener: bool,
    /// Explicit broadcast network choice. Never inferred from host/interface enumeration.
    pub discovery_network: Option<BroadcastNetwork>,
}
impl XdmcpConfig {
    pub fn is_default(&self) -> bool {
        self == &Self::default()
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct BroadcastNetwork {
    pub interface: Ipv4Addr,
    pub prefix: u8,
}
impl BroadcastNetwork {
    fn mask(self) -> Result<u32, String> {
        if !(16..=30).contains(&self.prefix)
            || self.interface.is_unspecified()
            || self.interface.is_multicast()
            || self.interface.is_loopback()
        {
            return Err(
                "Choose a local IPv4 interface and a /16 through /30 broadcast network".into(),
            );
        }
        Ok(u32::MAX << (32 - self.prefix))
    }
    fn destination(self, port: u16) -> Result<SocketAddr, String> {
        let mask = self.mask()?;
        Ok(SocketAddr::new(
            IpAddr::V4(Ipv4Addr::from(u32::from(self.interface) | !mask)),
            port,
        ))
    }
    fn admits(self, address: IpAddr) -> bool {
        matches!(address, IpAddr::V4(ip) if self.mask().is_ok_and(|mask| u32::from(ip)&mask == u32::from(self.interface)&mask))
    }
}
#[derive(Clone, Debug)]
pub struct DiscoveryRequest {
    pub endpoint: SocketAddr,
    pub mode: QueryMode,
    pub network: Option<BroadcastNetwork>,
}
impl DiscoveryRequest {
    pub fn direct(endpoint: SocketAddr) -> Self {
        Self {
            endpoint,
            mode: QueryMode::Direct,
            network: None,
        }
    }
    pub fn validate(&self) -> Result<(), String> {
        if self.endpoint.port() == 0
            || self.endpoint.ip().is_unspecified()
            || self.endpoint.ip().is_multicast()
        {
            return Err("Choose a unicast XDMCP endpoint and nonzero port".into());
        }
        if self.mode == QueryMode::Broadcast {
            self.network
                .ok_or("Broadcast discovery requires an explicit interface/network choice")?
                .mask()?;
        } else if self.endpoint.ip() == IpAddr::V4(Ipv4Addr::BROADCAST) {
            return Err("Choose Broadcast mode and an explicit network".into());
        }
        Ok(())
    }
}
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiscoveredEndpoint {
    pub address: SocketAddr,
    pub hostname: String,
    pub status: String,
}
fn field<'a>(bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < 2 {
        return None;
    };
    let n = u16::from_be_bytes([bytes[0], bytes[1]]) as usize;
    if n > 256 || bytes.len() < n + 2 {
        return None;
    };
    let result = &bytes[2..n + 2];
    *bytes = &bytes[n + 2..];
    Some(result)
}
fn advertisement(bytes: &[u8]) -> Option<String> {
    let value = std::str::from_utf8(bytes).ok()?;
    if value.chars().any(char::is_control) {
        return None;
    }
    Some(value.to_string())
}
fn parse_willing(bytes: &[u8]) -> Option<(String, String)> {
    if bytes.len() < 6
        || bytes.len() > 1024
        || bytes[..4] != [0, 1, 0, 5]
        || u16::from_be_bytes([bytes[4], bytes[5]]) as usize != bytes.len() - 6
    {
        return None;
    }
    let mut body = &bytes[6..];
    let _authentication = field(&mut body)?;
    let host = advertisement(field(&mut body)?)?;
    let status = advertisement(field(&mut body)?)?;
    if !body.is_empty() {
        return None;
    }
    Some((host, status))
}
/// Execute on a worker. At most 3 packets, 128 replies, 32 admitted endpoints and 600 ms.
/// XDMCP has no QUERY transaction ID; fresh ephemeral socket and source checks correlate replies.
pub fn discover(
    request: &DiscoveryRequest,
    cancelled: &AtomicBool,
) -> Result<Vec<DiscoveredEndpoint>, String> {
    request.validate()?;
    check_cancelled(cancelled)?;
    let bind = match request
        .network
        .filter(|_| request.mode == QueryMode::Broadcast)
    {
        Some(network) => SocketAddr::new(network.interface.into(), 0),
        None => {
            if request.endpoint.is_ipv4() {
                "0.0.0.0:0".parse().unwrap()
            } else {
                "[::]:0".parse().unwrap()
            }
        }
    };
    let socket =
        UdpSocket::bind(bind).map_err(|e| format!("Could not bind XDMCP discovery: {e}"))?;
    socket
        .set_read_timeout(Some(Duration::from_millis(30)))
        .map_err(|e| e.to_string())?;
    let target = if request.mode == QueryMode::Broadcast {
        socket.set_broadcast(true).map_err(|e| e.to_string())?;
        request
            .network
            .unwrap()
            .destination(request.endpoint.port())?
    } else {
        request.endpoint
    };
    let opcode = match request.mode {
        QueryMode::Direct => 2,
        QueryMode::Indirect => 3,
        QueryMode::Broadcast => 1,
    };
    let packet = [0, 1, 0, opcode, 0, 1, 0];
    let start = Instant::now();
    let mut next_send = Duration::ZERO;
    let mut sends = 0;
    let mut packets = 0;
    let mut results = BTreeMap::new();
    while start.elapsed() < Duration::from_millis(600) && packets < 128 && results.len() < 32 {
        check_cancelled(cancelled)?;
        if sends < 3 && start.elapsed() >= next_send {
            socket
                .send_to(&packet, target)
                .map_err(|e| format!("XDMCP query failed: {e}"))?;
            sends += 1;
            next_send = Duration::from_millis(sends * 200);
        }
        let mut buffer = [0; 1025];
        match socket.recv_from(&mut buffer) {
            Ok((n, source)) => {
                packets += 1;
                let allowed = if request.mode == QueryMode::Broadcast {
                    source.port() == target.port() && request.network.unwrap().admits(source.ip())
                } else {
                    source == target
                };
                if allowed {
                    if let Some((hostname, status)) = parse_willing(&buffer[..n]) {
                        results.insert(
                            source,
                            DiscoveredEndpoint {
                                address: source,
                                hostname,
                                status,
                            },
                        );
                    }
                }
            }
            Err(e)
                if matches!(
                    e.kind(),
                    std::io::ErrorKind::WouldBlock
                        | std::io::ErrorKind::TimedOut
                        | std::io::ErrorKind::Interrupted
                ) => {}
            Err(e) => return Err(format!("XDMCP reply failed: {e}")),
        }
    }
    check_cancelled(cancelled)?;
    Ok(results.into_values().collect())
}
pub(crate) fn check_cancelled(cancelled: &AtomicBool) -> Result<(), String> {
    if cancelled.load(Ordering::Relaxed) {
        Err("XDMCP cancelled".into())
    } else {
        Ok(())
    }
}
pub struct Discovery {
    cancelled: Arc<AtomicBool>,
    result: Receiver<Result<Vec<DiscoveredEndpoint>, String>>,
}
impl Discovery {
    pub fn start(request: DiscoveryRequest) -> Result<Self, String> {
        request.validate()?;
        let cancelled = Arc::new(AtomicBool::new(false));
        let stop = cancelled.clone();
        let (sender, result) = mpsc::sync_channel(1);
        std::thread::Builder::new()
            .name("termcraft-xdmcp-discovery".into())
            .spawn(move || {
                let _ = sender.send(discover(&request, &stop));
            })
            .map_err(|e| e.to_string())?;
        Ok(Self { cancelled, result })
    }
    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::Relaxed)
    }
    pub fn try_finish(&self) -> Option<Result<Vec<DiscoveredEndpoint>, String>> {
        match self.result.try_recv() {
            Ok(value) => Some(value),
            Err(mpsc::TryRecvError::Empty) => None,
            Err(_) => Some(Err("XDMCP discovery worker ended".into())),
        }
    }
}
impl Drop for Discovery {
    fn drop(&mut self) {
        self.cancel()
    }
}

/// Validated Xephyr options. Broadcast is discovery-only; connect to a selected endpoint.
pub fn engine_arguments(
    config: &XdmcpConfig,
    display: u16,
    width: u32,
    height: u32,
) -> Result<Vec<String>, String> {
    let endpoint = config
        .selected_endpoint
        .ok_or("Discover and select an XDMCP endpoint first")?;
    DiscoveryRequest::direct(endpoint).validate()?;
    if !endpoint.is_ipv4() {
        return Err("The owned Xephyr XDMCP candidate currently requires IPv4".into());
    }
    if !config.allow_network_listener {
        return Err("XDMCP needs an inbound X11 TCP listener. Explicitly allow its all-interface listener for this session on a trusted network".into());
    }
    if display < 1
        || display > 59535
        || !(200..=8192).contains(&width)
        || !(200..=8192).contains(&height)
    {
        return Err("Choose display 1–59535 and desktop dimensions 200–8192".into());
    }
    if config.display.is_some_and(|chosen| chosen != display) {
        return Err("Conflicting XDMCP display selection".into());
    }
    if config.clipboard != ClipboardPolicy::Disabled {
        return Err("Bidirectional host clipboard is unavailable for the owned Xephyr candidate; choose Disabled".into());
    }
    if config.mode == QueryMode::Broadcast {
        return Err(
            "Select a discovered endpoint and choose Direct or Indirect before connecting".into(),
        );
    }
    let source = config.advertise_address.unwrap_or(Ipv4Addr::LOCALHOST);
    if source.is_unspecified()
        || source.is_loopback()
        || source.is_multicast()
        || (!endpoint.ip().is_loopback()
            && (config.advertise_address.is_none() || source.is_loopback()))
    {
        return Err(
            "Choose the reachable local IPv4 address to advertise to this display manager".into(),
        );
    }
    let mut args = vec![
        format!(":{display}"),
        "-port".into(),
        endpoint.port().to_string(),
        match config.mode {
            QueryMode::Indirect => "-indirect",
            _ => "-query",
        }
        .into(),
        endpoint.ip().to_string(),
        "-from".into(),
        source.to_string(),
        "-once".into(),
        "-listen".into(),
        "tcp".into(),
        "-nopn".into(),
    ];
    if config.monitor.is_none() {
        args.extend(["-screen".into(), format!("{width}x{height}")]);
    }
    if config.fullscreen && config.monitor.is_none() {
        args.push("-fullscreen".into());
    }
    if let Some(monitor) = &config.monitor {
        if !config.fullscreen {
            return Err("Monitor selection requires full screen mode".into());
        }
        if monitor.is_empty()
            || monitor.len() > 128
            || !monitor
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b"-_.".contains(&b))
        {
            return Err("Choose a valid XRandR output name".into());
        }
        args.extend(["-output".into(), monitor.clone()]);
    }
    if !config.keyboard.is_empty() {
        return Err("The owned Xephyr engine inherits the host keyboard map; custom keyboard layouts are unavailable".into());
    }
    Ok(args)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{SocketAddr, UdpSocket};
    #[test]
    fn nondefault_port_is_used_and_only_correlated_willing_is_admitted() {
        let server = UdpSocket::bind("127.0.0.1:0").unwrap();
        let addr = server.local_addr().unwrap();
        let worker = std::thread::spawn(move || {
            let mut buf = [0; 512];
            let (n, peer) = server.recv_from(&mut buf).unwrap();
            assert_eq!(&buf[..n], &[0, 1, 0, 2, 0, 1, 0]);
            let forged = UdpSocket::bind("127.0.0.1:0").unwrap();
            forged
                .send_to(&[0, 1, 0, 5, 0, 6, 0, 0, 0, 0, 0, 0], peer)
                .unwrap();
            server.send_to(&[0, 1, 0, 5, 0, 1, 0], peer).unwrap();
            server
                .send_to(
                    &[
                        0, 1, 0, 5, 0, 14, 0, 0, 0, 4, b't', b'e', b's', b't', 0, 4, b'o', b'k',
                        b'a', b'y',
                    ],
                    peer,
                )
                .unwrap();
        });
        let result = discover(&DiscoveryRequest::direct(addr), &AtomicBool::new(false)).unwrap();
        worker.join().unwrap();
        assert_eq!(result.len(), 1);
        assert_eq!(result[0].address, addr);
        assert_eq!(result[0].hostname, "test");
    }
    #[test]
    fn cancellation_during_discovery_finishes_promptly() {
        let server = UdpSocket::bind("127.0.0.1:0").unwrap();
        server
            .set_read_timeout(Some(Duration::from_secs(1)))
            .unwrap();
        let discovery =
            Discovery::start(DiscoveryRequest::direct(server.local_addr().unwrap())).unwrap();
        server.recv_from(&mut [0; 32]).unwrap();
        let start = Instant::now();
        discovery.cancel();
        loop {
            if let Some(result) = discovery.try_finish() {
                assert!(result.unwrap_err().contains("cancel"));
                break;
            }
            assert!(start.elapsed() < Duration::from_millis(500));
            std::thread::sleep(Duration::from_millis(5));
        }
    }
    #[test]
    fn old_profiles_default_to_no_listener_and_round_trip_custom_options() {
        let config: XdmcpConfig = serde_json::from_str("{}").unwrap();
        assert!(config.is_default());
        assert!(!config.allow_network_listener);
        let config = XdmcpConfig {
            selected_endpoint: Some("192.0.2.2:1177".parse().unwrap()),
            display: Some(177),
            keyboard: "us".into(),
            ..Default::default()
        };
        assert_eq!(
            serde_json::from_str::<XdmcpConfig>(&serde_json::to_string(&config).unwrap()).unwrap(),
            config
        );
    }
    #[test]
    fn cancellation_prevents_any_packet() {
        let endpoint: SocketAddr = "127.0.0.1:1177".parse().unwrap();
        assert!(
            discover(&DiscoveryRequest::direct(endpoint), &AtomicBool::new(true))
                .unwrap_err()
                .contains("cancel")
        );
    }
    #[test]
    fn malformed_and_oversized_replies_are_rejected() {
        assert!(parse_willing(&[0, 1, 0, 5, 0, 1, 0]).is_none());
        assert!(parse_willing(&vec![0; 9000]).is_none());
    }
    #[test]
    fn listener_consent_and_selected_endpoint_are_required() {
        let mut config = XdmcpConfig::default();
        assert!(engine_arguments(&config, 120, 800, 600).is_err());
        config.selected_endpoint = Some("127.0.0.1:1177".parse().unwrap());
        assert!(
            engine_arguments(&config, 120, 800, 600)
                .unwrap_err()
                .contains("listener")
        );
        config.allow_network_listener = true;
        config.advertise_address = Some("192.0.2.1".parse().unwrap());
        config.fullscreen = true;
        config.monitor = Some("HEADLESS-1".into());
        config.keyboard = String::new();
        config.mode = QueryMode::Indirect;
        let args = engine_arguments(&config, 120, 800, 600).unwrap();
        for pair in [
            ["-port", "1177"],
            ["-indirect", "127.0.0.1"],
            ["-output", "HEADLESS-1"],
        ] {
            assert!(args.windows(2).any(|a| a == pair));
        }
        assert!(
            !args.contains(&"-fullscreen".into()),
            "-fullscreen causes upstream Xephyr to ignore -output"
        );
        assert!(
            !args.contains(&"-screen".into()),
            "-screen and -output create two separate Xephyr screens"
        );
        config.keyboard = "us".into();
        assert!(
            engine_arguments(&config, 120, 800, 600)
                .unwrap_err()
                .contains("keyboard")
        );
        config.keyboard.clear();
        assert!(!args.contains(&"-ac".into()));
        config.clipboard = ClipboardPolicy::Bidirectional;
        assert!(
            engine_arguments(&config, 120, 800, 600)
                .unwrap_err()
                .contains("clipboard")
        );
    }
    #[test]
    fn broadcast_requires_explicit_interface_choice() {
        let mut request = DiscoveryRequest::direct("127.0.0.1:1177".parse().unwrap());
        request.mode = QueryMode::Broadcast;
        assert!(request.validate().unwrap_err().contains("interface"));
    }
}
