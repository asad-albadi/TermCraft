use super::*;
use harbor_workspace::x11::{
    ManagedXdmcp, XServerManager,
    xdmcp::{
        BroadcastNetwork, ClipboardPolicy, DiscoveredEndpoint, Discovery, DiscoveryRequest,
        QueryMode,
    },
};
#[derive(Default)]
pub(super) struct State {
    pending: Option<Discovery>,
    endpoints: Vec<DiscoveredEndpoint>,
    error: String,
    fingerprint: String,
    session_id: String,
    interface: String,
    prefix: u8,
    advertise: String,
}
pub(super) fn settings(ui: &mut Ui, s: &mut Session, state: &mut State) {
    if state.session_id != s.id {
        *state = State {
            session_id: s.id.clone(),
            interface: s
                .xdmcp_options
                .discovery_network
                .map(|n| n.interface.to_string())
                .unwrap_or_default(),
            prefix: s
                .xdmcp_options
                .discovery_network
                .map(|n| n.prefix)
                .unwrap_or(24),
            advertise: s
                .xdmcp_options
                .advertise_address
                .map(|ip| ip.to_string())
                .unwrap_or_default(),
            ..Default::default()
        };
    }
    let fingerprint = format!(
        "{}:{}:{:?}:{:?}",
        s.host, s.port, s.xdmcp_options.mode, s.xdmcp_options.discovery_network
    );
    if state.fingerprint != fingerprint {
        state.pending = None;
        state.endpoints.clear();
        state.error.clear();
        state.fingerprint = fingerprint;
    }
    if let Some(result) = state.pending.as_ref().and_then(Discovery::try_finish) {
        state.pending = None;
        match result {
            Ok(endpoints) => state.endpoints = endpoints,
            Err(error) => state.error = error,
        }
    }
    let endpoint = s
        .host
        .parse::<std::net::IpAddr>()
        .ok()
        .map(|ip| std::net::SocketAddr::new(ip, s.port));
    if s.xdmcp_options.selected_endpoint != endpoint {
        s.xdmcp_options.selected_endpoint = None;
    }
    ui.horizontal_wrapped(|ui| {
        ui.label("Query mode");
        ui.selectable_value(&mut s.xdmcp_options.mode, QueryMode::Direct, "Direct");
        ui.selectable_value(
            &mut s.xdmcp_options.mode,
            QueryMode::Indirect,
            "Indirect chooser",
        );
        ui.selectable_value(
            &mut s.xdmcp_options.mode,
            QueryMode::Broadcast,
            "Broadcast discovery",
        );
    });
    if s.xdmcp_options.mode == QueryMode::Broadcast {
        if state.interface.is_empty() {
            if let Some(network) = s.xdmcp_options.discovery_network {
                state.interface = network.interface.to_string();
                state.prefix = network.prefix;
            } else {
                state.prefix = 24;
            }
        }
        ui.horizontal(|ui| {
            ui.label("Local interface IPv4");
            ui.text_edit_singleline(&mut state.interface);
            ui.label("Prefix");
            ui.add(DragValue::new(&mut state.prefix).range(16..=30));
        });
        s.xdmcp_options.discovery_network =
            state
                .interface
                .parse()
                .ok()
                .map(|interface| BroadcastNetwork {
                    interface,
                    prefix: state.prefix,
                });
        ui.small("Broadcast sends at most three discovery packets on the network you choose, only when you click Discover. Advertisements are unauthenticated.");
    }
    ui.horizontal(|ui| {
        if state.pending.is_some() {
            ui.spinner();
            if ui.button("Cancel discovery").clicked() {
                state.pending = None;
                state.endpoints.clear();
            }
        } else if ui.button("Discover endpoints").clicked() {
            let target = if s.xdmcp_options.mode == QueryMode::Broadcast {
                Some(std::net::SocketAddr::new(
                    std::net::Ipv4Addr::BROADCAST.into(),
                    s.port,
                ))
            } else {
                endpoint
            };
            match target
                .ok_or_else(|| "Enter a numeric IPv4/IPv6 address for bounded discovery".to_owned())
                .and_then(|endpoint| {
                    Discovery::start(DiscoveryRequest {
                        endpoint,
                        mode: s.xdmcp_options.mode,
                        network: s.xdmcp_options.discovery_network,
                    })
                }) {
                Ok(pending) => {
                    state.pending = Some(pending);
                    state.error.clear();
                    state.endpoints.clear();
                }
                Err(error) => state.error = error,
            }
        }
        if endpoint.is_some()
            && s.xdmcp_options.mode != QueryMode::Broadcast
            && ui.button("Use entered endpoint").clicked()
        {
            s.xdmcp_options.selected_endpoint = endpoint;
        }
    });
    if state.pending.is_some() {
        ui.ctx().request_repaint_after(Duration::from_millis(40));
    }
    for endpoint in &state.endpoints {
        if ui
            .selectable_label(
                s.xdmcp_options.selected_endpoint == Some(endpoint.address),
                format!(
                    "{} — {} — {}",
                    endpoint.address, endpoint.hostname, endpoint.status
                ),
            )
            .clicked()
        {
            s.host = endpoint.address.ip().to_string();
            s.port = endpoint.address.port();
            s.xdmcp_options.selected_endpoint = Some(endpoint.address);
            if s.xdmcp_options.mode == QueryMode::Broadcast {
                s.xdmcp_options.mode = QueryMode::Direct;
            }
        }
    }
    if !state.error.is_empty() {
        ui.colored_label(Color32::from_rgb(180, 42, 42), &state.error);
    }
    ui.small(format!(
        "Selected endpoint: {}",
        s.xdmcp_options
            .selected_endpoint
            .map(|v| v.to_string())
            .unwrap_or_else(|| "None".into())
    ));
    ui.horizontal(|ui| {
        let mut automatic = s.xdmcp_options.display.is_none();
        if ui
            .checkbox(&mut automatic, "Automatic free display")
            .changed()
        {
            s.xdmcp_options.display = if automatic { None } else { Some(100) }
        }
        if let Some(display) = &mut s.xdmcp_options.display {
            ui.add(DragValue::new(display).range(1..=59535));
        }
    });
    ui.horizontal(|ui| {
        ui.label("Desktop size");
        ui.add(DragValue::new(&mut s.width).range(200..=8192));
        ui.label("×");
        ui.add(DragValue::new(&mut s.height).range(200..=8192));
        ui.checkbox(&mut s.xdmcp_options.fullscreen, "Full screen");
    });
    ui.horizontal(|ui| {
        ui.label("Monitor output");
        let mut monitor = s.xdmcp_options.monitor.clone().unwrap_or_default();
        if ui
            .add(TextEdit::singleline(&mut monitor).hint_text("Default; e.g. HDMI-1"))
            .changed()
        {
            s.xdmcp_options.monitor = if monitor.is_empty() {
                None
            } else {
                Some(monitor)
            }
        }
    });
    ui.horizontal(|ui| {
        ui.label("Keyboard: inherited from the host X11 display");
        if !s.xdmcp_options.keyboard.is_empty() {
            ui.colored_label(Color32::RED, "Custom layout is unavailable for this engine");
            if ui.button("Use host keyboard").clicked() {
                s.xdmcp_options.keyboard.clear();
            }
        }
    });
    ui.horizontal(|ui| {
        ui.label("Host clipboard");
        ui.selectable_value(
            &mut s.xdmcp_options.clipboard,
            ClipboardPolicy::Disabled,
            "Disabled",
        );
        ui.add_enabled(
            false,
            egui::Button::new("Bidirectional (unavailable for this engine)"),
        );
    });
    if state.advertise.is_empty() {
        if let Some(ip) = s.xdmcp_options.advertise_address {
            state.advertise = ip.to_string();
        }
    }
    ui.horizontal(|ui| {
        ui.label("Advertised local IPv4");
        ui.add(
            TextEdit::singleline(&mut state.advertise)
                .hint_text("Reachable non-loopback local IPv4"),
        );
    });
    s.xdmcp_options.advertise_address = state.advertise.parse().ok();
    if !state.advertise.is_empty() && s.xdmcp_options.advertise_address.is_none() {
        ui.colored_label(Color32::RED, "Enter a valid local IPv4 address");
    }
    ui.checkbox(
        &mut s.xdmcp_options.allow_network_listener,
        "Allow unencrypted XDMCP/X11 and this session's TCP listener on all interfaces",
    );
    ui.small("XDMCP and X11 are unencrypted. Use a trusted isolated network. The advertised address does not restrict the TCP listener. X11 access control remains enabled. Linux requires the pinned owned Xephyr payload and a host X11 display; native Windows/macOS engines still require qualification.");
}
pub(super) fn start(session: &Session) -> Result<ManagedXdmcp, String> {
    let endpoint = session
        .xdmcp_options
        .selected_endpoint
        .ok_or("Choose an XDMCP endpoint in the session settings")?;
    if endpoint.port() != session.port
        || session.host.parse::<std::net::IpAddr>().ok() != Some(endpoint.ip())
    {
        return Err(
            "The selected XDMCP endpoint no longer matches this session. Select it again".into(),
        );
    }
    ManagedXdmcp::start(
        XServerManager::default(),
        session.xdmcp_options.clone(),
        session.width,
        session.height,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    fn render(session: &mut Session, state: &mut State) {
        let ctx = Context::default();
        let mut output = ctx.run_ui(egui::RawInput::default(), |ui| settings(ui, session, state));
        output.textures_delta.clear();
    }
    #[test]
    fn opening_broadcast_settings_never_starts_discovery() {
        let mut session = Session::default();
        session.protocol = "XDMCP".into();
        session.xdmcp_options.mode = QueryMode::Broadcast;
        session.xdmcp_options.discovery_network = Some(BroadcastNetwork {
            interface: "192.0.2.1".parse().unwrap(),
            prefix: 30,
        });
        let mut state = State::default();
        render(&mut session, &mut state);
        assert!(state.pending.is_none());
        assert!(state.endpoints.is_empty());
        assert!(!session.xdmcp_options.allow_network_listener);
    }
    #[test]
    fn editor_invalidates_stale_selection_and_does_not_carry_network_choices_between_profiles() {
        let mut session = Session::default();
        session.host = "192.0.2.3".into();
        session.port = 1177;
        session.xdmcp_options.selected_endpoint = Some("192.0.2.3:1177".parse().unwrap());
        session.xdmcp_options.advertise_address = Some("192.0.2.1".parse().unwrap());
        let mut state = State::default();
        render(&mut session, &mut state);
        assert!(session.xdmcp_options.selected_endpoint.is_some());
        session.port = 1178;
        render(&mut session, &mut state);
        assert!(session.xdmcp_options.selected_endpoint.is_none());
        let mut other = Session::default();
        render(&mut other, &mut state);
        assert!(other.xdmcp_options.advertise_address.is_none());
        assert!(state.advertise.is_empty());
    }
    #[test]
    fn workspace_routes_xdmcp_to_owned_session_and_rejects_stale_endpoint() {
        let mut session = Session::default();
        session.protocol = "XDMCP".into();
        session.host = "192.0.2.3".into();
        session.port = 1178;
        session.xdmcp_options.selected_endpoint = Some("192.0.2.3:1177".parse().unwrap());
        assert!(start(&session).err().unwrap().contains("no longer matches"));
        assert!(
            connection::launch(&session, &Preferences::default())
                .unwrap_err()
                .contains("per-session owned engine")
        );
    }
}
