# Packaged protocol runtimes

TermCraft uses embedded engines for SSH, SFTP, SCP, FTP/FTPS, VNC, Telnet, Rlogin, Rsh and Serial. The integrated RDP engine is a separate executable built from the locked source in `engines/rdp`. Released apps verify the app-adjacent executable against the package manifest before opening their private engine pipes. The package manifest provides consistency against accidental file changes and is unsigned. The standalone build script likewise writes an unsigned declaration beside its two binaries and uses Python 3.11 or later to do so.

The Arch Linux x86-64 release can include the Mosh wrapper and client. Supply the exact archive, corresponding source and Arch packaging recipe declared in [runtime-manifest.json](../runtime-manifest.json) to the packager:

```sh
python3 scripts/package-release.py \
  --mosh-archive /absolute/path/to/mosh-1.4.0-35-x86_64.pkg.tar.zst \
  --mosh-source /absolute/path/to/mosh-1.4.0.tar.gz \
  --mosh-recipe /absolute/path/to/PKGBUILD
```

The package includes the upstream source, license, Arch build recipe and inventory, and the local shebang patch. The app verifies the wrapper and client against pins compiled into the application. The qualified payload expects the Arch native library ABI, terminal definitions, Perl at `/usr/bin/perl`, and OpenSSH at `/usr/bin/ssh`. The server needs Mosh installed and must be reachable over UDP after SSH authentication. Installations without this payload can explicitly choose Installed Mosh. Existing Mosh profiles keep that provider.

The managed Xwayland variant can be combined with Mosh using the existing `--xwayland-archive` option. Its pinned declaration and host dependencies are in [the X server manifest](../x11/manifest.json). Embedded Browser on Linux uses the system Chromium executable from the installed Arch payload. Windows and macOS Mosh and Chromium packages are open qualification gaps.
