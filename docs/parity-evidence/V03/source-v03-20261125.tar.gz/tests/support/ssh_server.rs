use harbor_workspace::{model::Session, ssh::ConnectionConfig};
use std::{
    fs,
    net::{TcpListener, TcpStream},
    path::PathBuf,
    process::{Child, Command, Stdio},
    time::{Duration, Instant},
};
pub struct SshServer {
    pub root: PathBuf,
    pub port: u16,
    child: Child,
}
impl SshServer {
    pub fn start(sftp: bool) -> Self {
        Self::start_with_sftp_options(sftp, "")
    }
    pub fn start_with_sftp_options(sftp: bool, options: &str) -> Self {
        Self::start_with_settings(sftp, options, "")
    }
    pub fn start_with_settings(sftp: bool, options: &str, extra: &str) -> Self {
        // Reserve the selection→bind interval across parallel fixture startups.
        static STARTUP_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
        let _startup = STARTUP_LOCK.lock().unwrap_or_else(|p| p.into_inner());
        let root = std::env::temp_dir().join(format!(
            "termcraft-ssh-test-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&root).unwrap();
        for key in ["host", "client"] {
            let result = Command::new("ssh-keygen")
                .env_remove("LD_PRELOAD")
                .args(["-q", "-t", "ed25519", "-N", "", "-f"])
                .arg(root.join(key))
                .status()
                .unwrap();
            assert!(result.success());
        }
        fs::copy(root.join("client.pub"), root.join("authorized_keys")).unwrap();
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        drop(listener);
        let config = format!(
            "Port {port}\nListenAddress 127.0.0.1\nHostKey {}/host\nPidFile {}/pid\nAuthorizedKeysFile {}/authorized_keys\nStrictModes no\nPasswordAuthentication no\nKbdInteractiveAuthentication no\nUsePAM no\nPermitRootLogin yes\nLogLevel VERBOSE\n{}\n",
            root.display(),
            root.display(),
            root.display(),
            if sftp {
                format!("Subsystem sftp internal-sftp {options}")
            } else {
                String::new()
            }
        );
        fs::write(root.join("sshd_config"), format!("{config}\n{extra}\n")).unwrap();
        let mut child = Command::new("/usr/bin/sshd")
            .env_remove("LD_PRELOAD")
            .args(["-D", "-e", "-f"])
            .arg(root.join("sshd_config"))
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(fs::File::create(root.join("server.log")).unwrap())
            .spawn()
            .unwrap();
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            assert!(
                child.try_wait().unwrap().is_none(),
                "sshd exited: {}",
                fs::read_to_string(root.join("server.log")).unwrap()
            );
            if TcpStream::connect(("127.0.0.1", port)).is_ok() {
                break;
            }
            assert!(
                Instant::now() < deadline && child.try_wait().unwrap().is_none(),
                "sshd fixture failed: {}",
                fs::read_to_string(root.join("server.log")).unwrap()
            );
            std::thread::sleep(Duration::from_millis(20));
        }
        Self { root, port, child }
    }
    pub fn config(&self, id: u64, trust: bool) -> ConnectionConfig {
        let known = self.root.join("known_hosts");
        if trust {
            let pubkey = fs::read_to_string(self.root.join("host.pub")).unwrap();
            fs::write(&known, format!("[127.0.0.1]:{} {pubkey}", self.port)).unwrap();
        }
        ConnectionConfig {
            id,
            agent: None,
            defaults: Default::default(),
            clock: None,
            session: Session {
                host: "127.0.0.1".into(),
                port: self.port,
                user: std::env::var("USER").unwrap(),
                key: self.root.join("client").to_string_lossy().into(),
                directory: self.root.to_string_lossy().into(),
                command: "exec /bin/sh".into(),
                ..Default::default()
            },
            app_known_hosts: known,
            user_known_hosts: vec![],
        }
    }
    #[cfg(target_os = "linux")]
    pub fn terminate_owned_sftp(&self) {
        let mut queue = vec![self.child.id()];
        while let Some(pid) = queue.pop() {
            if let Ok(children) = fs::read_to_string(format!("/proc/{pid}/task/{pid}/children")) {
                queue.extend(
                    children
                        .split_whitespace()
                        .filter_map(|s| s.parse::<u32>().ok()),
                );
            }
            if let Ok(command) = fs::read(format!("/proc/{pid}/cmdline")) {
                if String::from_utf8_lossy(&command).contains("internal-sftp") {
                    assert_eq!(unsafe { libc::kill(pid as i32, libc::SIGTERM) }, 0);
                    return;
                }
            }
        }
        panic!("No owned fixture SFTP child found");
    }
    pub fn restart_with_new_host_key(&mut self) {
        self.child.kill().unwrap();
        self.child.wait().unwrap();
        for name in ["host", "host.pub"] {
            fs::remove_file(self.root.join(name)).unwrap();
        }
        assert!(
            Command::new("ssh-keygen")
                .args(["-q", "-t", "ed25519", "-N", "", "-f"])
                .arg(self.root.join("host"))
                .status()
                .unwrap()
                .success()
        );
        self.child = Command::new("/usr/bin/sshd")
            .env_remove("LD_PRELOAD")
            .args(["-D", "-e", "-f"])
            .arg(self.root.join("sshd_config"))
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(fs::File::create(self.root.join("server.log")).unwrap())
            .spawn()
            .unwrap();
        let deadline = Instant::now() + Duration::from_secs(5);
        while TcpStream::connect(("127.0.0.1", self.port)).is_err() {
            assert!(Instant::now() < deadline && self.child.try_wait().unwrap().is_none());
            std::thread::sleep(Duration::from_millis(10));
        }
    }
    pub fn accepted_authentications(&self) -> usize {
        fs::read_to_string(self.root.join("server.log"))
            .unwrap()
            .matches("Accepted publickey")
            .count()
    }
}
impl Drop for SshServer {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        // Opt-in evidence retention never includes private keys, credentials or config.
        if let Some(directory) = std::env::var_os("TERMCRAFT_INTEROP_LOG_DIR") {
            let directory = PathBuf::from(directory);
            fs::create_dir_all(&directory).expect("create fixture evidence directory");
            let name = self.root.file_name().unwrap().to_string_lossy();
            fs::copy(
                self.root.join("server.log"),
                directory.join(format!("{name}.log")),
            )
            .expect("retain owned OpenSSH server log");
        }
        let _ = fs::remove_dir_all(&self.root);
    }
}
