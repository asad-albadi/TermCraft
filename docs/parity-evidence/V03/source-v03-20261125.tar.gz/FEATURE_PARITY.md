# MobaXterm feature-parity matrix

Full feature parity is the acceptance target; it has NOT been achieved.
See [PARITY_CHECKLIST.md](PARITY_CHECKLIST.md) for the prioritized gap inventory, evidence questions, and validation gates.
Last reviewed: 2026-11-25. Implemented means the named capability exists,
not that every original edge case has been reproduced. Partial means a usable
subset or external adapter. Missing means there is no equivalent engine.
Platform-specific identifies a platform adapter needing native validation.

| Capability | Status | Platforms / dependency | Evidence and remaining differences |
| --- | --- | --- | --- |
| Local terminal | Implemented | Linux PTY; Windows ConPTY; macOS PTY | Linux shell execution tested. Windows 10 1809+ required. macOS runtime unverified. |
| ANSI / VT terminal emulation | Partial | All | Unicode/wide cells, indexed bounded history and VT regression cases are tested. Negotiated SGR/legacy mouse reporting has codec, viewport and owned PTY coverage. Full PuTTY/original and native platform conformance remain pending. |
| Terminal search, export and logging | Implemented | All | Local terminal output; original file formats and timing unverified. |
| Tabs, split terminals, MultiExec | Partial | All | Stable-ID tabs, resizable two-column/two-row/four-pane layouts and explicit MultiExec target selection, paged target views and failure reports. Layout and real-PTY broadcast tests pass; native/original comparison pending. Detach/reattach, custom tab titles and reversible fullscreen implemented; native window-manager comparison pending. |
| Session tree, quick connect, folders | Implemented | All | Save/edit/duplicate/search and JSON import/export. Saved sessions persist. |
| Collapsible / resizable session pane | Implemented | All | Sessions toolbar and Ctrl+Shift+B toggle; width and visibility persist. Other layout states remain incomplete. |
| Original session import and shared sessions | Partial | Bounded preview/import | Moba SSH bookmark INI/documented CSV and PuTTY SSH Registry import, encoding checks, duplicate policies and stable IDs implemented. Credentials/unsupported fields are excluded with warnings. Read-only file/HTTPS/SFTP shared sources, independent local copies, explicit refresh, private authentication and stale offline caches implemented. Typed vault integration is implemented for eligible SSH/SFTP/HTTPS prompts; native/original and broader format coverage remain pending. |
| SSH, keys, compression, jump host | Partial | Embedded russh; OpenSSH compatibility | Embedded direct/multi-hop sessions share shell/SFTP authentication and use app host-trust controls. Local OpenSSH and controlled auth tests cover key/password/MFA, cancellation and recovery. Cookie-spoofed local X11 forwarding is protocol-tested. Host certificates and broad server/native-platform validation remain incomplete. Legacy stores retain OpenSSH mode. |
| SSH companion SFTP session | Implemented | Installed sftp | Saved SSH context menu opens SFTP preserving host, user, port, key and gateway. Independent login may prompt again. |
| Graphical remote directory pane | Partial | Embedded SSH sessions | Automatic per-tab listing, directory navigation, parent/refresh, shared authentication and bounded background I/O. File/folder upload/download, mkdir/rename, confirmed deletion and separate upload/download drop zones are implemented. Opt-in OSC 7 folder following and connection-bound UTF-8 remote editing are implemented with Linux tests; native-platform/original validation remains pending. |
| SFTP transfer controls | Partial | Embedded SFTP; installed sftp compatibility | Graphical file/folder transfers with bounded progress/cancel, staging, merge/conflict handling and recoverable partials share SSH authentication. Linux endpoint/fault/UI routing cases pass; the Windows filesystem backend cross-checks, with native validation pending. |
| Remote editor | Partial | Embedded SFTP | Double-click UTF-8 text up to 2 MiB. Recovery snapshots precede staged saves; conflicts require a decision; dirty documents guard closing/reconnect. Reconnect retains dirty editors and offers explicit import into a freshly opened matching endpoint. Prompt-only usernames are conservatively refused for import. SFTP has a residual last-check/rename race; native/original validation remains pending. |
| SCP browser compatibility | Partial | Embedded SSH; remote POSIX Python 3 | Explicit selection with negotiated capabilities and shared SSH authentication. Linux tests cover byte-safe listings, staged file/folder transfers, per-entry merges/deletion, editing, conflicts and cancellation. Windows file/folder paths have compilation and portable-codec coverage; native Windows/macOS checks, Windows symlink/ACL behavior, other endpoints and original normal/enhanced-profile equivalence remain pending. |
| RDP | Partial | Embedded IronRDP helper; optional installed clients | In-workspace TLS/NLA, framebuffer/input, clipboard, vault/fullscreen, mapped folders/admin and Linux allocation with last-handle cleanup. The merged helper gate passed 55 tests, including pinned Unix serial PTYs, Linux CUPS printer and selected-reader PC/SC providers. Reviewed Windows opened-handle regular-file operations/serial and Darwin allocation source candidates are merged and component-checked. Linux POSIX rename/delete, native printer/smartcard providers, remaining serial/device families and actual native/original evidence remain open. |
| VNC | Partial | Embedded RFB/verified VeNCrypt; installed compatibility retained | Reviewed Linux checkpoint: Hextile/Raw/CopyRect, Rich Cursor, Unicode/Latin-1 clipboard, actual TCP and workspace frame/input/resize tests pass. Native/third-party/original validation pending. |
| X11 forwarding | Partial | Embedded authenticated display lease; explicit OpenSSH compatibility | Embedded cookie-spoofed forwarding shares SSH authentication. Linux can automatically start and retain the pinned owned Xwayland server, release it with its last client, and scope DISPLAY/Xauthority to child sessions. Native Windows/macOS source candidates remain disabled pending built-engine qualification; broader native/original validation remains open. |
| Embedded X server and extensions | Partial | Pinned Linux Xwayland; disabled Windows/macOS source candidates | Owned Linux server lifecycle and actual GLX rendering, Composite readback, RandR change/restoration pass isolated tests, including the extracted release app/engine. Native source/process/transport candidates and pinned upstream patches are reviewed, but patched native engine checksums/builds/runtime remain unavailable. No GPU/native/original equivalence claim. |
| System X server launcher | Platform-specific | Linux Xephyr; Windows VcXsrv; macOS XQuartz | Launch adapter only. Nested :2 is not automatically selected by SSH; external tools must be installed and configured. |
| Remote desktop environment over SSH | Partial | Embedded SSH and owned X forwarding | Reviewed per-session presets/custom exec channel, bounded startup progress and cancellation, shell-preserving failure. Actual isolated SSH/X launch fixtures pass; named full desktop environments, native providers and original comparison remain open. |
| XDMCP | Partial | Owned pinned Linux Xephyr; explicit system compatibility | Structured discovery/custom UDP port, monitor/fullscreen, cookie authentication, listener/process ownership and independent session cleanup pass actual isolated xdm tests. Native dedicated adapters, host clipboard bridging, custom keyboard, hostname/IPv6/chooser and original comparison remain open. |
| Telnet, Rsh, Rlogin | Partial | Embedded Rust transports | Reviewed Linux checkpoint: negotiation, configured ports/users, embedded terminal I/O and TCP/urgent-data fixtures. Rlogin/Rsh require reserved source ports and report unavailable access explicitly. Native/deployed/original interoperability remains pending. |
| FTP / FTPS | Partial | Embedded FTP/FTPS; installed-client compatibility | Reviewed Linux checkpoint: verified explicit/implicit TLS, data encryption, active/passive and ASCII, graphical browser/editor, file/folder merge/conflict/cancel/recovery and confirmed recursive deletion. MLSD required; server-side rename races and native/deployed/original comparisons remain open. |
| Mosh | Partial | Pinned Linux runtime; explicit installed compatibility | Real strict-key SSH bootstrap and Mosh UDP terminal pass with empty PATH. Linux runtime uses declared OS Perl/OpenSSH dependencies; roaming, native Windows/macOS and clean closure remain open. |
| Serial | Partial | Native POSIX / Windows APIs | Configurable data bits/parity/stop bits/flow control with legacy baud/8N1 compatibility, bounded cancellable reader and visible unplug errors. Five mapping/PTY/lifecycle tests and settings UI pass; Windows mapping source check passes. Native/physical and current full-host validation remain pending. |
| Local / remote / dynamic tunnels | Partial | Installed OpenSSH | Persistence and argument tests, including IPv6. Endpoint and original limit behavior require runtime comparison. |
| SSH gateway for other protocols | Partial | Embedded SSH + RDP/VNC/Telnet | Reviewed Linux checkpoint: separate gateway trust/auth, original target TLS/NLA identity, token-authenticated helper relay, same-login certificate retries, bounded cancellation and CLI failure cleanup. Native/deployed/original coverage pending. |
| Local file browser and text editor | Implemented | All | Real filesystem actions and non-overwriting copy; embedded SSH has a separate integrated remote editor. |
| HTTP file server | Partial | Native Rust | Reviewed Linux checkpoint: bearer auth, opt-in new-file uploads, HEAD/ranges/ETag, confined bounded I/O and background UI startup. Uploads require hard-link support; FAT/exFAT and native/original coverage remain open. |
| SSH/SFTP and Iperf servers | Partial | Embedded SSH/SFTP; pinned Linux Iperf2/3 | Reviewed owned services with persistent host keys, password/key auth, explicit roots/capabilities, actual OpenSSH and Iperf TCP/UDP interoperability, UI start/stop and bounded cancellation. Native/original qualification and non-Linux Iperf payloads remain open. |
| FTP/FTPS, TFTP, Telnet, VNC servers | Partial | Managed FTP/TFTP/Telnet; selected Linux X11 VNC; Windows VNC source candidate | Owned service configuration/lifetime and actual protocol/UI cases pass. VNC adds classic authentication, explicit unencrypted-transport consent, view-only default, optional input, actual X11 clipboard with Unicode/Latin-1 and independent-client checks. Native Windows capture/input/clipboard is compile-checked, runtime unrun; Wayland/macOS VNC, HTTP viewing and original/FTPS scope remain open. |
| NFS and cron services | Partial | Embedded managed NFSv3/MOUNTv3 and Cron | Read-only-default NFS with optional bounded writes passes independent libnfs interoperability, stale/alias/confinement and shutdown cases. Cron persists execution watermarks before spawning, owns its jobs and avoids duplicates across restart. Both are reviewed and covered by the 684-test combined gate; native/original service comparisons remain open. |
| Graphical and timed macros | Partial | Embedded terminals and RDP/VNC | Reviewed implementation checkpoint: timed text/key/pointer recording, bounded waits/calls and editor, per-connection playback, cancellation/release, startup attachment and named CLI invocation. PTY/SSH/RDP/VNC and GUI regressions pass; native/original timing and recurring scheduling scope remain pending. |
| Plugins and MobApt packages | Partial | All | Reviewed portable Unix packages and disabled-by-default, explicitly granted plugins are implemented with real Tools UI and lifecycle tests. Original MobApt/.mxt3 compatibility and native Windows/macOS execution remain unverified. |
| Password vault and SSH agent manager | Partial | Embedded SSH/SFTP and shared HTTPS | Opt-in Argon2id/XChaCha20-Poly1305 vault, background unlock/rekey/delete, endpoint-bound explicit save/use, and opaque session references are implemented. OTP/trust prompts are excluded; native ACL/UI and power-loss checks remain pending. Key generation/import, fingerprints, agent add/remove/lifetimes and separate owned-agent lifecycle are implemented. Owned/Pageant session selection requires embedded SSH; native Windows/macOS agent/UI validation remains pending. |
| Network and graphical tools | Partial | Native Rust; optional libpcap/Npcap | Reviewed Linux checkpoint: file/folder comparison, PNG/JPEG preview, explicit-unicast port scan and bounded cancellable PCAP capture, plus existing diagnostics. Real capture tested only in isolated loopback namespaces. Windows/macOS provider/runtime and original comparison remain pending. |
| Browser | Partial | Pinned bundled Chromium158 on Linux; native/system compatibility candidates | In-tab rendering/navigation/input/proxy/authentication/TLS and app workflows pass with the bundled runtime and empty PATH; renderer namespace/seccomp and cleanup checks pass. All browser resources, private simdutf, notices and source recipes are hashed in the tested Linux archive. Windows/macOS source backends are compile-checked; native payload/sandbox/runtime and clean-machine closure remain open. [Evidence](docs/parity-evidence/P01/browser-bundle.md). |
| Windows integrations | Partial | Native Win32 source candidate | Reviewed owned Explorer/protocol/file registration, drive mapping and confirmed typed registry browser/editor source are merged. Linux contract tests and Windows component checks pass; native Windows runtime and PowerShell/package integration remain unverified. Portable Unix tools are independent of Cygwin. |
| Games | Missing | All | No equivalent games. |
| Fluent presentation / original workflows | Partial | eframe / egui | Menus, command toolbar, rail, tree, tabs and status bar retained. Original screenshots referenced; exact layout and all expanded states unverified. |

## Verified evidence

Local tests exercise PTY command execution, terminal parsing, launch argument
preservation, store persistence, path handling and headless UI rendering.
A Linux build or Windows cargo check does not establish native Windows or macOS
runtime behavior. Owned OpenSSH, FTP/FTPS, RDP, VNC, Telnet, HTTP and other protocol fixtures now run locally. Physical serial hardware, native Windows/macOS and the original application runtime remain unavailable. See MECHANICS.md for decompilation evidence and estimated values.

Public references (reviewed 2026-11-23):
- https://mobaxterm.mobatek.net/documentation.html
- https://mobaxterm.mobatek.net/features.html (includes original interface images)

These sources establish original feature scope and workflow expectations, not
proof that this replacement implements those features.

## Defaults and assumptions

Protocol ports use standards: SSH/SFTP 22, Telnet 23, Rsh 514, Rlogin 513,
RDP 3389, VNC 5900, FTP 21, Mosh UDP 60000 and XDMCP 177. Their equality with
all original profiles remains unverified. SSH keepalive 60 seconds is estimated.
Compression defaults on. X11 defaults off in this build: this differs from the
original documented checked workflow and requires a configured system display.
Existing saved options are preserved. SSH host-key policy and authentication
follow the user's installed OpenSSH configuration; passwords are not saved by default; eligible integrated prompts can use the opt-in encrypted vault.
SFTP pipeline 32 and 32 KiB request blocks derive from inspected original handlers;
the OpenSSH adapter does not reproduce separate original upload window tuning.
Serial defaults to 9600 baud, 8N1. Remote desktop size defaults to 1280x800.
HTTP defaults to localhost:8080 and one hour; SSH server to localhost:2222,
key-only. Desktop dimensions and service defaults are estimates.

## Completion criteria

Missing and partial rows remain release blockers for the requested full-parity
replacement. Each needs an implementation, native Windows/Linux/macOS tests,
protocol endpoint tests and comparison evidence before becoming implemented.

Workspace W01–W05 now includes configurable conflict-checked shortcuts, local history controls and distinct unread/error indicators. Headless GUI and real-PTY coverage is retained in `docs/parity-evidence/`; native window-manager and original behavior comparisons remain pending.

Saved-folder launches and per-session results, argument-safe shortcut generation, validated CLI actions and same-workspace local IPC have implementation checkpoints. Linux real-binary forwarding is tested; Windows/macOS native shortcuts, ACLs, IPC and original-app comparisons remain pending.
